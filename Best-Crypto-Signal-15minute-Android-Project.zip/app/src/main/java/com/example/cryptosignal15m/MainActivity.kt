package com.example.cryptosignal15m

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import org.json.JSONArray
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*
import kotlin.concurrent.thread
import kotlin.math.max

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var details: TextView
    private lateinit var symbol: Spinner
    private val coins = listOf("BTCUSDT", "ETHUSDT", "SOLUSDT", "BNBUSDT")
    private val green = Color.rgb(22, 163, 74)
    private val red = Color.rgb(220, 38, 38)
    private val blue = Color.rgb(37, 99, 235)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 18, 32)
        window.navigationBarColor = Color.rgb(8, 18, 32)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 20)
            setBackgroundColor(Color.rgb(8, 18, 32))
        }
        fun label(text: String, size: Float, color: Int = Color.WHITE): TextView =
            TextView(this).apply { this.text = text; textSize = size; setTextColor(color); setPadding(0, 10, 0, 10) }
        root.addView(label("Best Crypto Signal 15M", 25f, Color.rgb(45, 212, 191)))
        root.addView(label("Live public market data • Binance • 15-minute candles", 13f, Color.LTGRAY))
        symbol = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, coins)
        }
        root.addView(symbol)
        val refresh = Button(this).apply { text = "Refresh Live Signal"; setOnClickListener { loadSignal() } }
        root.addView(refresh)
        status = label("Signal load karne ke liye Refresh dabayein.", 24f)
        root.addView(status)
        details = label("Entry / TP / SL market data aane par dikhaye jayenge.", 16f)
        root.addView(details)
        root.addView(label("Signal technical indicators par mabni estimate hai, guarantee nahi. Auto-trading OFF.", 13f, Color.YELLOW))
        val space = Space(this)
        root.addView(space, LinearLayout.LayoutParams(1, 0, 1f))
        root.addView(label("Updated time local device ke mutabiq • API keys ki zaroorat nahi", 12f, Color.LTGRAY))
        setContentView(root)
        loadSignal()
    }

    private fun loadSignal() {
        status.text = "Market data load ho raha hai..."
        details.text = ""
        val pair = symbol.selectedItem?.toString() ?: "BTCUSDT"
        thread {
            try {
                val url = URL("https://api.binance.com/api/v3/klines?symbol=$pair&interval=15m&limit=100")
                val raw = url.readText()
                val arr = JSONArray(raw)
                val closes = (0 until arr.length()).map { arr.getJSONArray(it).getString(4).toDouble() }
                val price = closes.last()
                val ema9 = ema(closes, 9)
                val ema21 = ema(closes, 21)
                val rsi = rsi(closes, 14)
                val signal = when {
                    ema9 > ema21 && rsi >= 52 && rsi < 70 -> "BUY"
                    ema9 < ema21 && rsi <= 48 && rsi > 30 -> "SELL"
                    else -> "WAIT"
                }
                val entry = price
                val tp = if (signal == "SELL") entry * 0.99 else entry * 1.01
                val sl = if (signal == "SELL") entry * 1.005 else entry * 0.995
                val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
                runOnUiThread {
                    status.text = "$signal  •  $pair"
                    status.setTextColor(when(signal) { "BUY" -> green; "SELL" -> red; else -> blue })
                    details.text = String.format(Locale.US,
                        "Live price: %.6f\nEMA 9: %.6f\nEMA 21: %.6f\nRSI (14): %.1f\n\nDemo plan (estimate only)\nEntry: %.6f\nTP: %.6f\nSL: %.6f\n\nUpdated: %s",
                        price, ema9, ema21, rsi, entry, tp, sl, stamp)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "DATA ERROR"
                    status.setTextColor(Color.YELLOW)
                    details.text = "Internet check karein aur dobara try karein.\n${e.message ?: "Market data unavailable"}"
                }
            }
        }
    }

    private fun ema(values: List<Double>, period: Int): Double {
        val alpha = 2.0 / (period + 1)
        var result = values.take(period).average()
        for (v in values.drop(period)) result = v * alpha + result * (1 - alpha)
        return result
    }

    private fun rsi(values: List<Double>, period: Int): Double {
        val changes = values.zipWithNext { a, b -> b - a }
        val last = changes.takeLast(period)
        val gains = last.filter { it > 0 }.sum() / period
        val losses = -last.filter { it < 0 }.sum() / period
        if (losses == 0.0) return 100.0
        val rs = gains / losses
        return 100.0 - 100.0 / (1.0 + rs)
    }
}
