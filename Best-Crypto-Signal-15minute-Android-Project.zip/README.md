# Best Crypto Signal 15minute (Android)

## Features
- Android app that fetches public Binance spot market 15-minute candles for BTCUSDT, ETHUSDT, SOLUSDT and BNBUSDT.
- Simple EMA(9)/EMA(21) + RSI(14) BUY/SELL/WAIT rule.
- Shows current price, indicative entry/TP/SL and local update timestamp.
- No exchange API keys, no trading permissions and no automatic orders.

## Build APK on GitHub
1. Upload the extracted project files and folders to the root of a GitHub repository (not the ZIP file alone).
2. Ensure `.github/workflows/android.yml` is present.
3. Open **Actions** → **Build Android APK** → **Run workflow**.
4. Wait for a green successful run.
5. Open the completed run and download the `Best-Crypto-Signal-15M-APK` artifact.
6. Extract the downloaded artifact ZIP; install `app-debug.apk` on Android.

## Important
This is an educational prototype. It uses public Binance spot candles, not Futures-specific prices. Signals are heuristic estimates, not financial advice or guaranteed outcomes. TP/SL shown are simple illustrative percentages, not optimized recommendations. Test before using real money. No live orders are placed.
